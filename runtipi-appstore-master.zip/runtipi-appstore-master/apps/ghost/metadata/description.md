# Install Information

After Ghost is installed, head over to https://yourdomain.com/ghost/ to finish setup and create the admin account!
# A painless self-hosted Blog

Ghost is a powerful app for new-media creators to publish, share, and grow a business around their content. It comes with modern tools to build a website, publish content, send newsletters & offer paid subscriptions to members.

![Screenshot](https://ghost.org/images/home/posts_hu3b21debb17401a2115316debd8fe8fa5_467056_2000x0_resize_q100_h2_box_3.webp)