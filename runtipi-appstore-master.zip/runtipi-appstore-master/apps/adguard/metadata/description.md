## AdGuard Home is a network-wide software for blocking ads & tracking.

After you set it up, it'll cover ALL your home devices, and you don't need any client-side software for that.
It operates as a DNS server that re-routes tracking domains to a "black hole", thus preventing your devices from connecting to those servers. It's based on software we use for our public AdGuard DNS servers -- both share a lot of common code.

![Screenshot](https://cdn.adguard.com/public/Adguard/Common/adguard_home.gif)
