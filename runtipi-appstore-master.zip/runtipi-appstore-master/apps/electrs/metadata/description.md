# Electrs

Electrum personal server to use bitcoin wallets more secure and more private. It makes it easy to connect your Electrum wallet to your own full node.

### Warning
First index synchronization can take up to a few days, depending on your hardware specifications. See the logs for detailed information.

## Required apps
To be able to run electrs, you need to install this apps first:
- Bitcoin: [Install here](/app-store/bitcoind)

![Electrs UI Screenshot](https://raw.githubusercontent.com/MontejoJorge/electrs-ui/master/electrs-ui-screenshot.png)