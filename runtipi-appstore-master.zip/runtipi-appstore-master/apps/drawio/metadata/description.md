## Draw.io

draw.io, this project, is a configurable diagramming/whiteboarding visualization application. draw.io is jointly owned and developed by JGraph Ltd and draw.io AG.

As well as running this project, we run a production-grade deployment of the diagramming interface at [https://app.diagrams.net](https://app.diagrams.net).
