# Open source website building tool

[Halo](https://github.com/halo-dev/halo) is a powerful and easy-to-use open source website building tool, with rich themes and plugins to help you build the ideal site in your mind.

## Links

- Repository: <https://github.com/halo-dev/halo>
- Awesome Halo: <https://github.com/halo-sigs/awesome-halo>
- Homepage: <https://halo.run>