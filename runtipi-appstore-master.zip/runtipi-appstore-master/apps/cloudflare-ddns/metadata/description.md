# Cloudflare DDNS

Cloudflare DDNS is a Docker image that update DNS records on Cloudflare on schedule.

<https://github.com/joshuaavalon/docker-cloudflare>

> Warning ⚠️: This app is no longer maintained, you can keep using it but you may face issues. If you want a maintained alternative you can try the `DDNS Updater` app.
