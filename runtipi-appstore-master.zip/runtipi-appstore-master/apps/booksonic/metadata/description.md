Booksonic Air is a server for hosting the audiobooks you own and reach them from wherever you are.

Check out [Booksonic App](https://github.com/popeen/Booksonic-App) for connecting to Booksonic servers.
<br />
Once installed you can setup the following folders : /audiobooks, /podcasts

# Folder Info

| Root Folder                         | Container Folder |
|-------------------------------------|------------------|
| /runtipi/app-data/booksonic/config	 | /config          |
| /runtipi/media/data/books/spoken    | /audiobooks      |
| /runtipi/media/data/podcasts        | /podcasts        |