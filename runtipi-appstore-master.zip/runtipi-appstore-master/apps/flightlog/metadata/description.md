# Flightlog: Easily keep track of your personal flight history

Flightlog is a web application inspired by [Flugstatistik](https://flugstatistik.de), with more features, a modern UI and a streamlined user experience.

Read more on [GitHub](https://github.com/perdian/flightlog)
