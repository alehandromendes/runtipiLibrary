# Hello World
Tiny app that prints "Hello World" in the browser. Can be used to test the deployment of a new app.
