##  High performance self-hosted photo and video backup solution. 

An open source, high performance self-hosted backup solution for videos and photos on your mobile phone

![Screenshot](https://raw.githubusercontent.com/immich-app/immich/main/design/immich-screenshots.png)
