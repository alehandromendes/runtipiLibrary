# Important Info

- This is a beta build of the new Jellyfin Vue UI. You still need an exisiting Jellyfin server. T
- This will have bugs and Issues, as its a Beta, Unstable Build.


# Jellyfin Vue

### Part of the [Jellyfin Project](https://jellyfin.org)

___

[![Logo Banner](https://raw.githubusercontent.com/jellyfin/jellyfin-ux/master/branding/SVG/banner-logo-solid.svg?sanitize=true)](https://raw.githubusercontent.com/jellyfin/jellyfin-ux/master/branding/SVG/banner-logo-solid.svg?sanitize=true)

This is an alternative client for Jellyfin based on Vue.js. It might not be feature complete and it's constantly evolving.