# Kanboard

Kanboard is a free and open source Kanban project management software.

## Default credentials
Username: admin
Password: admin

## Hint
**Plugins currently not installable via Kanboard Web Interface**

- Kanban Board
- Visualize your work
- Limit your work in progress to focus on your goal
- Drag and drop tasks to manage your project

![screenshot](https://kanboard.org/assets/img/board.png)

Source: https://kanboard.org/
