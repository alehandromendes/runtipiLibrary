# Folder Info 

| Root Folder                                 | Container Folder |
|---------------------------------------------|------------------|
| /runtipi/app-data/deemix/data/deemix-config | /config          |
| /runtipi/media                              | /media           |
| /runtipi/media/data/torrents/deemix         | /downloads       |
| /runtipi/media/data/music                   | /music           |

deemix is a library that lets you download millions of songs, soundtracks, albums in high-quality mp3 and FLAC. Here you can find discussions about the apps that use the deemix library. Deemix is meant to replace Deezloader Remix.
