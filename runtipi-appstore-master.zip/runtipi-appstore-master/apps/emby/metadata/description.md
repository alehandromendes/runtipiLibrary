## Emby

Bringing all of your home videos, music, and photos together into one place has never been easier. Your personal Emby Server automatically converts and streams your media on-the-fly to play on any device.

![Emby](https://emby.media/resources/Screenshot_2015-09-28-22-42-491.png)

### Folder Info

| Root Folder                            | Container Folder |
|----------------------------------------|------------------|
| /runtipi/app-data/emby/data/config     | /config          |
| /runtipi/media/data                    | /media/data      |
