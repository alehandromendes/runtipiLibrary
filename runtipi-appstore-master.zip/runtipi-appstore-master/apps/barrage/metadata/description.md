# Barrage

Minimal Deluge WebUI with full mobile support

## [](https://github.com/maulik9898/barrage/blob/main/README.md#features)Features

- Responsive mobile first design
- Add torrent by URL or magnet
- Sort and Filter Torrents
- Global upload and Download speed limits
- Change File Priority
- Change Torrent options
