Calibre-Web is a web app providing a clean interface for browsing, reading and downloading eBooks using a valid Calibre database.

#### On the initial setup screen :
1. Enter `/calibre` as your calibre library location.
2. Check box : *Separate Book Files from Library*
3. Enter `/books` as book path.

#### Default credentials :
- **username**: admin
- **password**: admin123
