DokuWiki - Documentation Wiki Platform
======================================

`DokuWiki`_ is wiki software aimed at small companies documentation
needs. It works on plain text files and thus needs no database. It has a
simple but powerful syntax (similar to the one used by MediaWiki) which
makes sure the data files remain readable outside the wiki and eases the
creation of structured texts.