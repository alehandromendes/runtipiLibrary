## Get A Shell 🐚

**warning ⚠️:** This app is no longer maintained and it can be a security risk since it has access to the docker daemon. It is recommended you uninstall it.

**Warning ⚠️:** If you are updating to version 1.0.0 make sure to set a username and a password in the settings menu.

Have you ever wanted to just spin up a quick server than you can ssh into to test something real quick? Well with get a shell
you can just spin up the ui select a distro and click _Get me a shell!_ and 💥 you have an ssh server with your specified distro. No need to spin up vms, run commands or anything harder than a click!

> Warning ⚠️: The app is in early stages of development, I am still quite new to both writing full stack apps and using technologies like drizzle and react. Any contributions are welcome.

![Preview](https://github.com/steveiliop56/getashell/blob/main/screenshots/app.png?raw=true)
